<?php
$facebook = new Facebook(array(
  'appId'  => '279825898886500', // my app id
  'secret' => '6e88fc8934b7b4fa9af2cabba6866edc', // my secret key
  'fileUpload' => true // this for file upload
));